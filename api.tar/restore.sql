--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.1
-- Dumped by pg_dump version 12.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE api;
--
-- Name: api; Type: DATABASE; Schema: -; Owner: jv
--

CREATE DATABASE api WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE api OWNER TO jv;

\connect api

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: pictures; Type: TABLE; Schema: public; Owner: jv
--

CREATE TABLE public.pictures (
    img_id integer NOT NULL,
    img_link character varying(255),
    user_id integer
);


ALTER TABLE public.pictures OWNER TO jv;

--
-- Name: pictures_img_id_seq; Type: SEQUENCE; Schema: public; Owner: jv
--

CREATE SEQUENCE public.pictures_img_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pictures_img_id_seq OWNER TO jv;

--
-- Name: pictures_img_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jv
--

ALTER SEQUENCE public.pictures_img_id_seq OWNED BY public.pictures.img_id;


--
-- Name: profile; Type: TABLE; Schema: public; Owner: jv
--

CREATE TABLE public.profile (
    user_id integer NOT NULL,
    lastname character varying(50),
    firstname character varying(50),
    gender character varying(50),
    interested character varying(50),
    country character varying(50),
    birthday date,
    bio character varying(255)
);


ALTER TABLE public.profile OWNER TO jv;

--
-- Name: profile_id_seq; Type: SEQUENCE; Schema: public; Owner: jv
--

CREATE SEQUENCE public.profile_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.profile_id_seq OWNER TO jv;

--
-- Name: profile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jv
--

ALTER SEQUENCE public.profile_id_seq OWNED BY public.profile.user_id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: jv
--

CREATE TABLE public.users (
    user_id integer NOT NULL,
    username character varying(255),
    email character varying(255),
    password character varying(255),
    tokenmail integer DEFAULT 0,
    complete integer DEFAULT 0,
    active integer DEFAULT 0
);


ALTER TABLE public.users OWNER TO jv;

--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: jv
--

CREATE SEQUENCE public.users_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_id_seq OWNER TO jv;

--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jv
--

ALTER SEQUENCE public.users_user_id_seq OWNED BY public.users.user_id;


--
-- Name: pictures img_id; Type: DEFAULT; Schema: public; Owner: jv
--

ALTER TABLE ONLY public.pictures ALTER COLUMN img_id SET DEFAULT nextval('public.pictures_img_id_seq'::regclass);


--
-- Name: users user_id; Type: DEFAULT; Schema: public; Owner: jv
--

ALTER TABLE ONLY public.users ALTER COLUMN user_id SET DEFAULT nextval('public.users_user_id_seq'::regclass);


--
-- Data for Name: pictures; Type: TABLE DATA; Schema: public; Owner: jv
--

COPY public.pictures (img_id, img_link, user_id) FROM stdin;
\.
COPY public.pictures (img_id, img_link, user_id) FROM '$$PATH$$/3209.dat';

--
-- Data for Name: profile; Type: TABLE DATA; Schema: public; Owner: jv
--

COPY public.profile (user_id, lastname, firstname, gender, interested, country, birthday, bio) FROM stdin;
\.
COPY public.profile (user_id, lastname, firstname, gender, interested, country, birthday, bio) FROM '$$PATH$$/3205.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: jv
--

COPY public.users (user_id, username, email, password, tokenmail, complete, active) FROM stdin;
\.
COPY public.users (user_id, username, email, password, tokenmail, complete, active) FROM '$$PATH$$/3207.dat';

--
-- Name: pictures_img_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jv
--

SELECT pg_catalog.setval('public.pictures_img_id_seq', 35, true);


--
-- Name: profile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jv
--

SELECT pg_catalog.setval('public.profile_id_seq', 3, true);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jv
--

SELECT pg_catalog.setval('public.users_user_id_seq', 15, true);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: jv
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- PostgreSQL database dump complete
--

